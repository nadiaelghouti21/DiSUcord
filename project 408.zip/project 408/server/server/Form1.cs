﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Runtime.Remoting.Channels;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace server
{
    public partial class Form1 : Form
    {

        Socket serverSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);

        Dictionary<string, Socket> clientDict = new Dictionary<string, Socket>();


        bool terminating = false;
        bool listening = false;

        public Form1()
        {
            Control.CheckForIllegalCrossThreadCalls = false;
            this.FormClosing += new FormClosingEventHandler(Form1_FormClosing);
            InitializeComponent();
        }

        private void button_listen_Click(object sender, EventArgs e)
        {
            int serverPort;

            if (Int32.TryParse(textBox_port.Text, out serverPort))
            {
                IPEndPoint endPoint = new IPEndPoint(IPAddress.Any, serverPort);
                serverSocket.Bind(endPoint);
                serverSocket.Listen(3);

                listening = true;
                button_listen.Enabled = false;
               
                button_send.Enabled = true;

                Thread acceptThread = new Thread(Accept);
                acceptThread.Start();

                logs.AppendText("Started listening on port: " + serverPort + "\n");

            }
            else
            {
                logs.AppendText("Please check port number \n");
            }
        }

        object clientDictLock = new object();
        private void UpdateConnectedClientsList()
        {
            // Clear the existing list
            connected_clients_list.Text = "";

            lock (clientDictLock)
            {
                foreach (var client in clientDict.Keys)
                {
                    connected_clients_list.AppendText(client + "\n");
                }
            }
        }
        // RichTextBox to display clients subscribed to IF 100 channel
        private void UpdateIFChannelSubscribersList()
        {
            // Clear the existing list
            if_subscribers_list.Text = "";

            lock (clientDictLock)
            {
                foreach (var subscriber in ifChannelSubscribers)
                {
                    if_subscribers_list.AppendText(subscriber + "\n");
                }
            }
        }

        // RichTextBox to display clients subscribed to SPS 101 channel
        private void UpdateSPSChannelSubscribersList()
        {
            // Clear the existing list
            sps_subscribers_list.Text = "";

            lock (clientDictLock)
            {
                foreach (var subscriber in spsChannelSubscribers)
                {
                    sps_subscribers_list.AppendText(subscriber + "\n");
                }
            }
        }



        private void Accept()
        {
            while (listening)
            {
                try
                {
                    Socket newClient = serverSocket.Accept();

                    byte[] usernameBuffer = new byte[64];
                    int receivedBytes = newClient.Receive(usernameBuffer);
                    string newUsername = Encoding.Default.GetString(usernameBuffer, 0, receivedBytes).Trim();

                    lock (clientDictLock)
                    {
                        if (clientDict.ContainsKey(newUsername))//incase the username is already used
                        {
                            logs.AppendText("Illegal duplicate username: " + newUsername + "\n");
                            newClient.Close();
                        }
                        else
                        {
                            clientDict.Add(newUsername, newClient);
                            logs.AppendText(newUsername + " is connected to the server\n");
                            UpdateConnectedClientsList();
                            Thread clientThread = new Thread(() => HandleClient(newClient, newUsername));
                            clientThread.Start();
                        }
                    }
                }
                catch (Exception ex)
                {
                    if (terminating)
                    {
                        listening = false;
                    }
                    else
                    {
                        logs.AppendText("The socket stopped working. Exception: " + ex.Message + "\n");
                    }
                }
            }
        }


        private void Form1_FormClosing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            listening = false;
            terminating = true;

            Environment.Exit(0);
        }

        List<string> clientsToRemove = new List<string>();

        void BroadcastToSubscribers(List<string> channelSubscribers, string message)
        {
            foreach (string subscriber in channelSubscribers)
            {
                Socket subscriberSocket;

                if (clientDict.TryGetValue(subscriber, out subscriberSocket))
                {
                    byte[] data = Encoding.Default.GetBytes(message);
                    try
                    {
                        subscriberSocket.Send(data);
                    }
                    catch
                    {
                        subscriberSocket.Close();
                        clientDict.Remove(subscriber);
                    }
                }
            }
        }


        List<string> ifChannelSubscribers = new List<string>();
        List<string> spsChannelSubscribers = new List<string>();

        void HandleClient(Socket clientSocket, string username)
        {
            try
            {
                while (!terminating)
                {
                    Byte[] buffer = new Byte[1024];
                    int receivedBytes = clientSocket.Receive(buffer);

                    if (receivedBytes > 0)
                    {
                        string receivedText = Encoding.Default.GetString(buffer, 0, receivedBytes);

                        if (receivedText.StartsWith("SUBSCRIBE_IF:")) //in case the user try to subcribe to if
                        {
                            Subscribe(ifChannelSubscribers, receivedText, "IF", username);
                        }
                        else if (receivedText.StartsWith("UNSUBSCRIBE_IF:")) // in case user trys to unsubcribe to if
                        {
                            Unsubscribe(ifChannelSubscribers, receivedText, "IF");
                            
                        }
                        else if (receivedText.StartsWith("SUBSCRIBE_SPS:"))//in case user trys to unsubcribe to sps
                        {
                            Subscribe(spsChannelSubscribers, receivedText, "SPS", username);
                        }
                        else if (receivedText.StartsWith("UNSUBSCRIBE_SPS:"))// in case user trys to unsubcribe to sps
                         {
                            Unsubscribe(spsChannelSubscribers, receivedText, "SPS");
                        }
                        else if (receivedText.StartsWith("CHANNEL_MESSAGE:")) //if we are reciving the meassage 
                        {
                            receivedText = receivedText.Substring("CHANNEL_MESSAGE:".Length);

                            if (receivedText.StartsWith("IF:")) //check from which channel
                            {
                                logs.AppendText(username + ": " + receivedText + "\n");
                                BroadcastToSubscribers(ifChannelSubscribers, receivedText + " " + username);
                              

                            }
                            else if (receivedText.StartsWith("SPS:"))
                            {
                                logs.AppendText(username + ": " + receivedText + "\n");
                                BroadcastToSubscribers(spsChannelSubscribers, receivedText + " " + username);
                               

                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {

            }
            finally
            {
                lock (clientDictLock)
                {
                    logs.AppendText("Client " + username + " has disconnected\n");
                    clientSocket.Close();
                    clientDict.Remove(username);
                    ifChannelSubscribers.Remove(username);
                    spsChannelSubscribers.Remove(username);
                    UpdateConnectedClientsList();
                }
            }
        }

        void Subscribe(List<string> channelSubscribers, string receivedText, string channelName, string username)
        {
            string newUsername = receivedText.Substring($"SUBSCRIBE_{channelName}:".Length);
            channelSubscribers.Add(newUsername);
            string message = $"{newUsername} has subscribed to {channelName}\n";
            logs.AppendText(message);
            if (channelName == "IF")
            {
                UpdateIFChannelSubscribersList();
            }
            else if (channelName == "SPS")
            {
                UpdateSPSChannelSubscribersList();
            }

        }

        void Unsubscribe(List<string> channelSubscribers, string receivedText, string channelName)
        {
            string usernameToUnsubscribe = receivedText.Substring($"UNSUBSCRIBE_{channelName}:".Length);
           
            if (channelSubscribers.Contains(usernameToUnsubscribe))
            {
                channelSubscribers.Remove(usernameToUnsubscribe);
                string message = $"{usernameToUnsubscribe} has unsubscribed from {channelName}\n";
                logs.AppendText(message);
                if (channelName == "IF")
                {
                    UpdateIFChannelSubscribersList();
                }
                else if (channelName == "SPS")
                {
                    UpdateSPSChannelSubscribersList();
                }
            }
        }

       
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox_message_TextChanged(object sender, EventArgs e)
        {

        }
    }
}

