﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Sockets;
using System.Windows.Forms;
using System.Threading;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Runtime.Remoting.Messaging;


namespace proj_408
{
    public partial class Form1 : Form
    {
        //flags to manage application state
        bool terminating = false;
        bool connected = false;
        Socket clientsocket;
        public Form1()
        {
            // Allow cross-thread calls to update UI controls
            Control.CheckForIllegalCrossThreadCalls = false;
            //subscribe to the form closing event
            this.FormClosing += new FormClosingEventHandler(Form1_FormClosing);
            //intialize the form component 
            InitializeComponent();

        }
        //event handler for the form closing
        private void Form1_FormClosing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            //handle form closing
            connected = false;
            terminating = true;
            Environment.Exit(0);
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void ip_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }


        private void sps_TextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void richTextBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }
        //incase the user click the connect button
        private void connect_Click(object sender, EventArgs e)
        {
            //take the user inputs
            string ip = this.ip.Text;
            string pass = port.Text;
            string user = this.user.Text;
            clientsocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            int portNum;
            if (ip == "" || pass == "" || user == "") //CHECK IF THE INPUT BOX IS EMPTY
            {
                connect_button.BackColor = Color.Red;
            }
            else if (Int32.TryParse(pass, out portNum))
            { //checking the port number
                try
                {
                    clientsocket.Connect(ip, portNum); //build connection to server

                    byte[] username = Encoding.Default.GetBytes(user);
                    clientsocket.Send(username); //sending the username to server

                    port.Enabled = false; //disableing the already connection input boxes
                    this.ip.Enabled = false;
                    this.user.Enabled = false;

                    connect_button.Enabled = false;
                    //enabling the connection to the channel inputs
                    connected = true; 
                    sub_SPS.Enabled = true;
                    sub_IF.Enabled = true;
                    connect_button.BackColor = Color.Green;
                    disconnect_button.Enabled = true;
                    disconnect_button.BackColor = Color.Red;
                    server_textBox.AppendText("Welcome to SUDiscord!\n");
                    server_textBox.AppendText("You may choose the channels on the right for subscriptions :) \n");
                    Thread receiveThread = new Thread(Receive);
                    receiveThread.Start();

                }
                catch
                {
                    server_textBox.AppendText("Could not connect to the server!\n");
                }
            }
            else
            {
                //the port number is wrong
                server_textBox.AppendText("Check the port\n");
            }


        }

        private void Receive()
        {
            while (connected)
            {
                try
                {
                    //reciving message from the server
                    Byte[] buffer = new Byte[64];
                    int receivedByte = clientsocket.Receive(buffer);

                    if (receivedByte > 0)
                    {
                        //changing the message fro server to string type
                        string incomingMessage = Encoding.Default.GetString(buffer, 0, receivedByte);

                        //chek the message contenet 
                        if (incomingMessage.StartsWith("IF:"))
                        {
                            UpdateTextWithChannel(incomingMessage, chatbox_IF100);
                        }
                        else if (incomingMessage.StartsWith("SPS:"))
                        {
                            UpdateTextWithChannel(incomingMessage, chatbox_SPS101);
                        }
                    }
                }
                catch
                {
                    //handle the disconncetion from server case
                    if (!terminating)
                    {
                        server_textBox.AppendText("The server has disconnected\n");
                        connect_button.Enabled = true;
                        ip.Enabled = true;
                        port.Enabled = true;
                    }

                    clientsocket.Close();
                    connected = false;
                }
            }
        }

        private void UpdateTextWithChannel(string message, RichTextBox textBox)
        {
            if (textBox.InvokeRequired) //if the thread is called
            {
                // Invoke the update operation on the UI thread
                textBox.Invoke(new Action<string>((msg) =>
                {
                    // Find the index of the last space in the existing text
                    int last_space = msg.LastIndexOf(' ');
                    // Check if a space is found in the existing text
                    if (last_space != -1)
                    {
                        // Extract the last word from the existing text
                        string lastWord = msg.Substring(last_space + 1);
                        string channelPrefix = "";
                        // Check if the message starts with "IF:" or "SPS:"
                        if (msg.StartsWith("IF:"))
                        {
                            channelPrefix = "IF:";
                        }
                        else if (msg.StartsWith("SPS:"))
                        {
                            channelPrefix = "SPS:";
                        }
                        // Check if a channel prefix is identified
                        if (!string.IsNullOrEmpty(channelPrefix))
                        {
                            // Extract channel-specific information and append it to the RichTextBox
                            textBox.AppendText(lastWord + ": " + msg.Substring(channelPrefix.Length, last_space - channelPrefix.Length) + "\n");
                        }
                        else
                        {
                            // No channel prefix, append the message as is
                            textBox.AppendText(msg + "\n");
                        }
                    }
                    else
                    {
                        // No space found, append the message as is
                        textBox.AppendText(msg + "\n");
                    }
                }), message);
            }
            else
            {
                // No invoking required, directly append the message to the RichTextBox
                textBox.AppendText(message + "\n");
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        private void send_button_Click(object sender, EventArgs e)
        {

        }
        //incase the user subsribe to if100
        private void sub_if100_button_Click(object sender, EventArgs e)
        {
            //enabling the channel inputs
            sendtxt_if.Enabled = true;
            txt_from_IF.Enabled = true;

            sub_IF.Enabled = false;
            chatbox_IF100.Enabled = true;
            usub_IF100.Enabled = true;

            sub_IF.BackColor = Color.Green;
            //incase the connection to server presist
            if (connected && clientsocket != null)
            {
                try
                {
                    string username = user.Text;  //taking the username
                    string message = "SUBSCRIBE_IF:" + username; //appending the username to the channel
                    byte[] messageBytes = Encoding.Default.GetBytes(message);
                    clientsocket.Send(messageBytes); //sending the message to the server
                    chatbox_IF100.AppendText("Welcome to IF 100 channel\n"); // append message on the chat box
                }
                catch (Exception ex)
                {
                    server_textBox.AppendText("Error in sending request: " + ex.Message + "\n"); //error in infrom the server
                }
            }
            else
            {
                server_textBox.AppendText("Not connected to the server.\n"); //connection to server is not succesful
            }
        }
        //incase the user press the unsubcribtion button
        private void unsub_if100_button_Click(object sender, EventArgs e)
        {
            //disable the input boxes
            sub_IF.Enabled = true;
            usub_IF100.Enabled = false;
            usub_IF100.BackColor = Color.Red;
            sendtxt_if.Enabled = false;
            txt_from_IF.Enabled = false;
            chatbox_IF100.Enabled = false;
            //incase connection presists 
            if (connected && clientsocket != null)
            {
                try
                {
                    string username = user.Text;
                    string message = "UNSUBSCRIBE_IF:" + username;

                    byte[] messageBytes = Encoding.Default.GetBytes(message);
                    clientsocket.Send(messageBytes); //inform the server about the disconnection
                    chatbox_IF100.AppendText("Unsubscribed from IF 100 discord channel\n");
                }
                catch (Exception ex)
                {
                    server_textBox.AppendText("Error in sending unsubscription request: " + ex.Message + "\n");
                }
            }
            else
            {
                server_textBox.AppendText("Not connected to the server.\n");
            }
        }

        //incase the user press the subscrib button 
        private void sub_SPS101_button_Click(object sender, EventArgs e)
        {
            //the steps below are hte same as the subscribe to if channel code. 
            unsub_SPS101.Enabled = true;
            sub_SPS.Enabled = false;
            sub_SPS.BackColor = Color.Green;
            sendtxt_sps.Enabled = true;
            txt_from_SPS.Enabled = true;
            chatbox_SPS101.Enabled = true;

            if (connected && clientsocket != null)
            {
                try
                {
                    string username = user.Text;
                    string message = "SUBSCRIBE_SPS:" + username;

                    byte[] messageBytes = Encoding.Default.GetBytes(message);
                    clientsocket.Send(messageBytes); //infrom the server about the subscribtion
                    chatbox_SPS101.AppendText("Welcome to SPS 100 channel\n");
                }
                catch (Exception ex)
                {
                    server_textBox.AppendText("Error in sending subscription request: " + ex.Message + "\n");
                }
            }
            else
            {
                server_textBox.AppendText("Not connected to the server.\n");
            }

        }
        //incase the the user press the unsubcribe button
        //the code is the same as the unsubcribe from if channel code
        private void unsub_SPS101_button_Click(object sender, EventArgs e)
        {

            sub_SPS.Enabled = true;
            unsub_SPS101.Enabled = false;
            unsub_SPS101.BackColor = Color.Red;
            sendtxt_sps.Enabled = false;
            txt_from_SPS.Enabled = false;
            chatbox_SPS101.Enabled = false;

            if (connected && clientsocket != null)
            {
                try
                {
                    string username = user.Text;
                    string message = "UNSUBSCRIBE_SPS:" + username;
                    byte[] messageBytes = Encoding.Default.GetBytes(message);
                    clientsocket.Send(messageBytes);
                    chatbox_SPS101.AppendText("Unsubscribed from SPS100 channel\n");
                }
                catch (Exception ex)
                {
                    server_textBox.AppendText("Error in sending unsubscription request: " + ex.Message + "\n");
                }
            }
            else
            {
                server_textBox.AppendText("Not connected to the server.\n");
            }
        }



        private void txt_from_if_box_TextChanged(object sender, EventArgs e)
        {

        }
        //sending a text to the discord channel
        private void sendtext_if_button_Click(object sender, EventArgs e)
        {
            if (connected && clientsocket != null && !string.IsNullOrWhiteSpace(txt_from_IF.Text))
            {
                string message = "CHANNEL_MESSAGE:IF:" + txt_from_IF.Text;
                byte[] messageBytes = Encoding.Default.GetBytes(message);
                clientsocket.Send(messageBytes); //sending to the server the text
                txt_from_IF.Clear(); //clear the text box
            }
        }


        private void txt_from_sps_box_TextChanged(object sender, EventArgs e)
        {

        }

        private void sendtxt_sps_button_Click(object sender, EventArgs e)
        {
            if (connected && clientsocket != null && !string.IsNullOrWhiteSpace(txt_from_SPS.Text))
            {
                string message = "CHANNEL_MESSAGE:SPS:" + txt_from_SPS.Text;
                byte[] messageBytes = Encoding.Default.GetBytes(message);
                clientsocket.Send(messageBytes);
                txt_from_SPS.Clear();
            }
        }

        //incase of disconnection
        private void disconnect_button_Click(object sender, EventArgs e)
        {
            try
            {
                if (connected && clientsocket != null)
                {
                    //disable all channel input and subscribtion functionality and enable the conniction input (ip,port, username)
                    terminating = true;
                    connected = false;
                    clientsocket.Close();

                    connect_button.Enabled = true;
                    ip.Enabled = true;
                    port.Enabled = true;
                    usub_IF100.Enabled = false;
                    sub_IF.Enabled = false;
                    sendtxt_if.Enabled = false;
                    txt_from_IF.Enabled = false;
                    chatbox_IF100.Enabled = false;
                    unsub_SPS101.Enabled = false;
                    sub_SPS.Enabled = false;
                    sendtxt_sps.Enabled = false;
                    txt_from_SPS.Enabled = false;
                    chatbox_SPS101.Enabled = false;

                    server_textBox.AppendText("Disconnected from the server\n");
                }
                else
                {
                    server_textBox.AppendText("Not connected to the server.\n");
                }
            }
            catch (Exception ex)
            {
                server_textBox.AppendText("Error during disconnection: " + ex.Message + "\n");
            }
        }

    }
}
