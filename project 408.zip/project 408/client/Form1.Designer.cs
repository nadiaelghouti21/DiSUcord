﻿
namespace proj_408
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ip_label = new System.Windows.Forms.Label();
            this.chatbox_IF100 = new System.Windows.Forms.RichTextBox();
            this.chatbox_SPS101 = new System.Windows.Forms.RichTextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.port_label = new System.Windows.Forms.Label();
            this.connect_button = new System.Windows.Forms.Button();
            this.ip = new System.Windows.Forms.TextBox();
            this.port = new System.Windows.Forms.TextBox();
            this.user = new System.Windows.Forms.TextBox();
            this.server_textBox = new System.Windows.Forms.RichTextBox();
            this.label_sps = new System.Windows.Forms.Label();
            this.label_if = new System.Windows.Forms.Label();
            this.sub_IF = new System.Windows.Forms.Button();
            this.sub_SPS = new System.Windows.Forms.Button();
            this.usub_IF100 = new System.Windows.Forms.Button();
            this.unsub_SPS101 = new System.Windows.Forms.Button();
            this.txt_from_IF = new System.Windows.Forms.TextBox();
            this.txt_from_SPS = new System.Windows.Forms.TextBox();
            this.sendtxt_if = new System.Windows.Forms.Button();
            this.sendtxt_sps = new System.Windows.Forms.Button();
            this.disconnect_button = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // ip_label
            // 
            this.ip_label.AutoSize = true;
            this.ip_label.Location = new System.Drawing.Point(24, 28);
            this.ip_label.Name = "ip_label";
            this.ip_label.Size = new System.Drawing.Size(32, 20);
            this.ip_label.TabIndex = 0;
            this.ip_label.Text = "IP :";
            this.ip_label.Click += new System.EventHandler(this.label1_Click);
            // 
            // chatbox_IF100
            // 
            this.chatbox_IF100.Enabled = false;
            this.chatbox_IF100.Location = new System.Drawing.Point(12, 401);
            this.chatbox_IF100.Name = "chatbox_IF100";
            this.chatbox_IF100.Size = new System.Drawing.Size(334, 271);
            this.chatbox_IF100.TabIndex = 1;
            this.chatbox_IF100.Text = "";
            // 
            // chatbox_SPS101
            // 
            this.chatbox_SPS101.Enabled = false;
            this.chatbox_SPS101.Location = new System.Drawing.Point(740, 397);
            this.chatbox_SPS101.Name = "chatbox_SPS101";
            this.chatbox_SPS101.Size = new System.Drawing.Size(334, 275);
            this.chatbox_SPS101.TabIndex = 2;
            this.chatbox_SPS101.Text = "";
            this.chatbox_SPS101.TextChanged += new System.EventHandler(this.sps_TextBox_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(24, 116);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(91, 20);
            this.label3.TabIndex = 4;
            this.label3.Text = "Username :";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // port_label
            // 
            this.port_label.AutoSize = true;
            this.port_label.Location = new System.Drawing.Point(24, 76);
            this.port_label.Name = "port_label";
            this.port_label.Size = new System.Drawing.Size(46, 20);
            this.port_label.TabIndex = 5;
            this.port_label.Text = "Port :";
            // 
            // connect_button
            // 
            this.connect_button.Location = new System.Drawing.Point(434, 28);
            this.connect_button.Name = "connect_button";
            this.connect_button.Size = new System.Drawing.Size(246, 47);
            this.connect_button.TabIndex = 6;
            this.connect_button.Text = "CONNECT";
            this.connect_button.UseVisualStyleBackColor = true;
            this.connect_button.Click += new System.EventHandler(this.connect_Click);
            // 
            // ip
            // 
            this.ip.Location = new System.Drawing.Point(132, 28);
            this.ip.Name = "ip";
            this.ip.Size = new System.Drawing.Size(229, 26);
            this.ip.TabIndex = 7;
            this.ip.TextChanged += new System.EventHandler(this.ip_TextChanged);
            // 
            // port
            // 
            this.port.Location = new System.Drawing.Point(132, 73);
            this.port.Name = "port";
            this.port.Size = new System.Drawing.Size(229, 26);
            this.port.TabIndex = 8;
            // 
            // user
            // 
            this.user.Location = new System.Drawing.Point(132, 113);
            this.user.Name = "user";
            this.user.Size = new System.Drawing.Size(229, 26);
            this.user.TabIndex = 9;
            this.user.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // server_textBox
            // 
            this.server_textBox.Location = new System.Drawing.Point(740, 1);
            this.server_textBox.Name = "server_textBox";
            this.server_textBox.Size = new System.Drawing.Size(645, 178);
            this.server_textBox.TabIndex = 17;
            this.server_textBox.Text = "";
            this.server_textBox.TextChanged += new System.EventHandler(this.richTextBox1_TextChanged);
            // 
            // label_sps
            // 
            this.label_sps.AutoSize = true;
            this.label_sps.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.1F);
            this.label_sps.Location = new System.Drawing.Point(743, 256);
            this.label_sps.Name = "label_sps";
            this.label_sps.Size = new System.Drawing.Size(154, 35);
            this.label_sps.TabIndex = 18;
            this.label_sps.Text = "SPS 101 :";
            this.label_sps.Click += new System.EventHandler(this.label2_Click);
            // 
            // label_if
            // 
            this.label_if.AutoSize = true;
            this.label_if.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.1F);
            this.label_if.Location = new System.Drawing.Point(6, 256);
            this.label_if.Name = "label_if";
            this.label_if.Size = new System.Drawing.Size(118, 35);
            this.label_if.TabIndex = 19;
            this.label_if.Text = "IF 100 :";
            // 
            // sub_IF
            // 
            this.sub_IF.Enabled = false;
            this.sub_IF.Location = new System.Drawing.Point(364, 436);
            this.sub_IF.Margin = new System.Windows.Forms.Padding(2);
            this.sub_IF.Name = "sub_IF";
            this.sub_IF.Size = new System.Drawing.Size(321, 76);
            this.sub_IF.TabIndex = 20;
            this.sub_IF.Text = "SUBSCRIBE IF100";
            this.sub_IF.UseVisualStyleBackColor = true;
            this.sub_IF.Click += new System.EventHandler(this.sub_if100_button_Click);
            // 
            // sub_SPS
            // 
            this.sub_SPS.Enabled = false;
            this.sub_SPS.Location = new System.Drawing.Point(1093, 436);
            this.sub_SPS.Margin = new System.Windows.Forms.Padding(2);
            this.sub_SPS.Name = "sub_SPS";
            this.sub_SPS.Size = new System.Drawing.Size(321, 76);
            this.sub_SPS.TabIndex = 21;
            this.sub_SPS.Text = "SUBSCRIBE SPS101";
            this.sub_SPS.UseVisualStyleBackColor = true;
            this.sub_SPS.Click += new System.EventHandler(this.sub_SPS101_button_Click);
            // 
            // usub_IF100
            // 
            this.usub_IF100.Enabled = false;
            this.usub_IF100.Location = new System.Drawing.Point(364, 562);
            this.usub_IF100.Margin = new System.Windows.Forms.Padding(2);
            this.usub_IF100.Name = "usub_IF100";
            this.usub_IF100.Size = new System.Drawing.Size(321, 76);
            this.usub_IF100.TabIndex = 22;
            this.usub_IF100.Text = "UNSUBSCRIBE  IF100";
            this.usub_IF100.UseVisualStyleBackColor = true;
            this.usub_IF100.Click += new System.EventHandler(this.unsub_if100_button_Click);
            // 
            // unsub_SPS101
            // 
            this.unsub_SPS101.Enabled = false;
            this.unsub_SPS101.Location = new System.Drawing.Point(1093, 562);
            this.unsub_SPS101.Margin = new System.Windows.Forms.Padding(2);
            this.unsub_SPS101.Name = "unsub_SPS101";
            this.unsub_SPS101.Size = new System.Drawing.Size(321, 76);
            this.unsub_SPS101.TabIndex = 23;
            this.unsub_SPS101.Text = "UNSUBSCRIBE SPS101";
            this.unsub_SPS101.UseVisualStyleBackColor = true;
            this.unsub_SPS101.Click += new System.EventHandler(this.unsub_SPS101_button_Click);
            // 
            // txt_from_IF
            // 
            this.txt_from_IF.Enabled = false;
            this.txt_from_IF.Location = new System.Drawing.Point(11, 311);
            this.txt_from_IF.Margin = new System.Windows.Forms.Padding(2);
            this.txt_from_IF.Name = "txt_from_IF";
            this.txt_from_IF.Size = new System.Drawing.Size(335, 26);
            this.txt_from_IF.TabIndex = 25;
            this.txt_from_IF.TextChanged += new System.EventHandler(this.txt_from_if_box_TextChanged);
            // 
            // txt_from_SPS
            // 
            this.txt_from_SPS.Enabled = false;
            this.txt_from_SPS.Location = new System.Drawing.Point(740, 311);
            this.txt_from_SPS.Margin = new System.Windows.Forms.Padding(2);
            this.txt_from_SPS.Name = "txt_from_SPS";
            this.txt_from_SPS.Size = new System.Drawing.Size(334, 26);
            this.txt_from_SPS.TabIndex = 26;
            this.txt_from_SPS.TextChanged += new System.EventHandler(this.txt_from_sps_box_TextChanged);
            // 
            // sendtxt_if
            // 
            this.sendtxt_if.Enabled = false;
            this.sendtxt_if.Location = new System.Drawing.Point(396, 309);
            this.sendtxt_if.Margin = new System.Windows.Forms.Padding(2);
            this.sendtxt_if.Name = "sendtxt_if";
            this.sendtxt_if.Size = new System.Drawing.Size(82, 37);
            this.sendtxt_if.TabIndex = 27;
            this.sendtxt_if.Text = "SEND";
            this.sendtxt_if.UseVisualStyleBackColor = true;
            this.sendtxt_if.Click += new System.EventHandler(this.sendtext_if_button_Click);
            // 
            // sendtxt_sps
            // 
            this.sendtxt_sps.Enabled = false;
            this.sendtxt_sps.Location = new System.Drawing.Point(1127, 311);
            this.sendtxt_sps.Margin = new System.Windows.Forms.Padding(2);
            this.sendtxt_sps.Name = "sendtxt_sps";
            this.sendtxt_sps.Size = new System.Drawing.Size(89, 32);
            this.sendtxt_sps.TabIndex = 28;
            this.sendtxt_sps.Text = "SEND";
            this.sendtxt_sps.UseVisualStyleBackColor = true;
            this.sendtxt_sps.Click += new System.EventHandler(this.sendtxt_sps_button_Click);
            // 
            // disconnect_button
            // 
            this.disconnect_button.Enabled = false;
            this.disconnect_button.Location = new System.Drawing.Point(434, 116);
            this.disconnect_button.Margin = new System.Windows.Forms.Padding(2);
            this.disconnect_button.Name = "disconnect_button";
            this.disconnect_button.Size = new System.Drawing.Size(246, 44);
            this.disconnect_button.TabIndex = 29;
            this.disconnect_button.Text = "DISCONNECT";
            this.disconnect_button.UseVisualStyleBackColor = true;
            this.disconnect_button.Click += new System.EventHandler(this.disconnect_button_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1415, 734);
            this.Controls.Add(this.disconnect_button);
            this.Controls.Add(this.sendtxt_sps);
            this.Controls.Add(this.sendtxt_if);
            this.Controls.Add(this.txt_from_SPS);
            this.Controls.Add(this.txt_from_IF);
            this.Controls.Add(this.unsub_SPS101);
            this.Controls.Add(this.usub_IF100);
            this.Controls.Add(this.sub_SPS);
            this.Controls.Add(this.sub_IF);
            this.Controls.Add(this.label_if);
            this.Controls.Add(this.label_sps);
            this.Controls.Add(this.server_textBox);
            this.Controls.Add(this.user);
            this.Controls.Add(this.port);
            this.Controls.Add(this.ip);
            this.Controls.Add(this.connect_button);
            this.Controls.Add(this.port_label);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.chatbox_SPS101);
            this.Controls.Add(this.chatbox_IF100);
            this.Controls.Add(this.ip_label);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label ip_label;
        private System.Windows.Forms.RichTextBox chatbox_IF100;
        private System.Windows.Forms.RichTextBox chatbox_SPS101;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label port_label;
        private System.Windows.Forms.Button connect_button;
        private System.Windows.Forms.TextBox ip;
        private System.Windows.Forms.TextBox port;
        private System.Windows.Forms.TextBox user;
        private System.Windows.Forms.RichTextBox server_textBox;
        private System.Windows.Forms.Label label_sps;
        private System.Windows.Forms.Label label_if;
        private System.Windows.Forms.Button sub_IF;
        private System.Windows.Forms.Button sub_SPS;
        private System.Windows.Forms.Button usub_IF100;
        private System.Windows.Forms.Button unsub_SPS101;
        private System.Windows.Forms.TextBox txt_from_IF;
        private System.Windows.Forms.TextBox txt_from_SPS;
        private System.Windows.Forms.Button sendtxt_if;
        private System.Windows.Forms.Button sendtxt_sps;
        private System.Windows.Forms.Button disconnect_button;
    }
}

